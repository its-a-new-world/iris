import { motion } from 'motion/react';
import DeadlineCard from './DeadlineCard';
import NotificationCard from './NotificationCard';

const mockDeadlines = [
  {
    id: '1',
    title: 'Midterm Exams',
    category: 'Academic',
    daysLeft: 3,
    urgency: 'urgent' as const,
    date: '2026-04-17',
  },
  {
    id: '2',
    title: 'Scholarship Application',
    category: 'Financial Aid',
    daysLeft: 7,
    urgency: 'pending' as const,
    date: '2026-04-21',
  },
  {
    id: '3',
    title: 'Project Submission - AI Lab',
    category: 'Assignment',
    daysLeft: 5,
    urgency: 'urgent' as const,
    date: '2026-04-19',
  },
  {
    id: '4',
    title: 'Summer Internship Registration',
    category: 'Career',
    daysLeft: 14,
    urgency: 'info' as const,
    date: '2026-04-28',
  },
];

const mockNotifications = [
  {
    id: '1',
    sender: 'Dr. Sarah Mitchell',
    senderRole: 'HOD - Computer Science',
    category: 'Academic',
    title: 'Important: Midterm Exam Schedule Released',
    preview: 'The midterm examination schedule for Spring 2026 has been finalized. Please review the dates and report any conflicts...',
    fullContent: 'The midterm examination schedule for Spring 2026 has been finalized. All students are required to review the dates carefully and report any conflicts to the academic office within 48 hours. Exams will begin on April 17, 2026. Make-up exams will only be granted for medical emergencies with proper documentation.',
    hasAttachment: true,
    timestamp: '2 hours ago',
    isRead: false,
    urgency: 'urgent' as const,
  },
  {
    id: '2',
    sender: 'Financial Aid Office',
    senderRole: 'Administration',
    category: 'Scholarship',
    title: 'Merit Scholarship Applications Now Open',
    preview: 'Applications for the 2026-27 Merit Scholarship program are now being accepted. Deadline: April 21, 2026...',
    fullContent: 'We are pleased to announce that applications for the 2026-27 Merit Scholarship program are now open. Eligible students can apply through the student portal. Required documents include academic transcripts, recommendation letters, and a personal statement. For more information, visit the Financial Aid office or attend the info session on April 16.',
    hasAttachment: false,
    timestamp: '5 hours ago',
    isRead: false,
    urgency: 'pending' as const,
  },
  {
    id: '3',
    sender: 'Dr. James Rodriguez',
    senderRole: 'Faculty - AI Department',
    category: 'Assignment',
    title: 'AI Lab Project - Submission Guidelines Updated',
    preview: 'Please note the updated submission guidelines for the AI Lab final project. All submissions must include...',
    fullContent: 'The submission guidelines for the AI Lab final project have been updated. All submissions must now include a detailed README file, test cases, and a 5-minute video presentation. Code must be pushed to the designated GitHub Classroom repository by 11:59 PM on April 19, 2026. Late submissions will incur a 10% penalty per day.',
    hasAttachment: true,
    timestamp: '1 day ago',
    isRead: true,
    urgency: 'info' as const,
  },
  {
    id: '4',
    sender: 'Career Services',
    senderRole: 'Department',
    category: 'Internship',
    title: 'Summer 2026 Internship Fair - Register Now',
    preview: 'Join us for the Summer Internship Fair featuring 50+ companies. Registration is mandatory...',
    fullContent: 'The Summer 2026 Internship Fair will be held on April 25, 2026 in the Main Auditorium. Over 50 companies will be present, including tech giants and innovative startups. Registration is mandatory through the career portal. Prepare your resume and dress professionally. One-on-one mock interviews are available upon request.',
    hasAttachment: false,
    timestamp: '2 days ago',
    isRead: true,
    urgency: 'info' as const,
  },
  {
    id: '5',
    sender: 'Campus Security',
    senderRole: 'Administration',
    category: 'Campus',
    title: 'Updated Campus Access Hours',
    preview: 'Effective immediately, campus library hours have been extended for exam preparation...',
    fullContent: 'To support students during the exam period, the campus library will now be open 24/7 starting April 14, 2026 until April 24, 2026. Students must present their ID cards for after-hours access. Study rooms are available on a first-come, first-served basis.',
    hasAttachment: false,
    timestamp: '3 days ago',
    isRead: true,
    urgency: 'completed' as const,
  },
];

interface StudentDashboardProps {
  searchQuery: string;
  onNotificationClick: (notification: any) => void;
}

export default function StudentDashboard({ searchQuery, onNotificationClick }: StudentDashboardProps) {
  const filteredNotifications = mockNotifications.filter(
    (notif) =>
      notif.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notif.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notif.sender.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Deadline Tracker */}
      <section className="mb-8">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Upcoming Deadlines</h2>
            <p className="text-sm text-muted-foreground mt-1">Stay on top of your important dates</p>
          </div>
          <button className="text-sm text-primary hover:underline">View all</button>
        </div>

        <div className="relative">
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-border scrollbar-track-transparent">
            {mockDeadlines.map((deadline, index) => (
              <motion.div
                key={deadline.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <DeadlineCard {...deadline} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Notifications Feed */}
      <section>
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Notifications</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {filteredNotifications.filter((n) => !n.isRead).length} unread messages
            </p>
          </div>
          <div className="flex gap-2">
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              All
            </button>
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              Unread
            </button>
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              Urgent
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification, index) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <NotificationCard
                  {...notification}
                  onClick={() => onNotificationClick(notification)}
                  role="student"
                />
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>No notifications found matching "{searchQuery}"</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
