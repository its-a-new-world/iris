import { motion } from 'motion/react';
import { TrendingUp, Users, CheckCircle2, Clock } from 'lucide-react';
import MetricCard from './MetricCard';
import NotificationCard from './NotificationCard';

const mockMetrics = [
  {
    id: '1',
    label: 'Messages Sent',
    value: '124',
    change: '+12%',
    trend: 'up' as const,
    icon: Users,
  },
  {
    id: '2',
    label: 'Overall Read Rate',
    value: '87.3%',
    change: '+5.2%',
    trend: 'up' as const,
    icon: CheckCircle2,
  },
  {
    id: '3',
    label: 'Pending Acknowledgements',
    value: '23',
    change: '-8',
    trend: 'down' as const,
    icon: Clock,
  },
  {
    id: '4',
    label: 'Most Engaged Dept',
    value: 'CS',
    change: '92% rate',
    trend: 'up' as const,
    icon: TrendingUp,
  },
];

const mockSentNotifications = [
  {
    id: '1',
    sender: 'You',
    senderRole: 'HOD - Computer Science',
    category: 'Academic',
    title: 'Important: Midterm Exam Schedule Released',
    preview: 'The midterm examination schedule for Spring 2026 has been finalized...',
    fullContent: 'The midterm examination schedule for Spring 2026 has been finalized. All students are required to review the dates carefully and report any conflicts to the academic office within 48 hours.',
    hasAttachment: true,
    timestamp: '2 hours ago',
    isRead: false,
    urgency: 'urgent' as const,
    audience: 'All CS Students (342)',
    readRate: 73,
    totalRecipients: 342,
    readCount: 250,
  },
  {
    id: '2',
    sender: 'You',
    senderRole: 'HOD - Computer Science',
    category: 'Assignment',
    title: 'AI Lab Project - Submission Guidelines Updated',
    preview: 'Please note the updated submission guidelines for the AI Lab final project...',
    fullContent: 'The submission guidelines for the AI Lab final project have been updated. All submissions must now include a detailed README file, test cases, and a 5-minute video presentation.',
    hasAttachment: true,
    timestamp: '1 day ago',
    isRead: true,
    urgency: 'info' as const,
    audience: 'CS Year 3 (89)',
    readRate: 94,
    totalRecipients: 89,
    readCount: 84,
  },
  {
    id: '3',
    sender: 'You',
    senderRole: 'HOD - Computer Science',
    category: 'Department',
    title: 'Department Meeting - Faculty Only',
    preview: 'Monthly department meeting scheduled for April 16, 2026...',
    fullContent: 'The monthly department meeting will be held on April 16, 2026 at 3:00 PM in Conference Room A. Agenda items include curriculum review and upcoming accreditation.',
    hasAttachment: false,
    timestamp: '3 days ago',
    isRead: true,
    urgency: 'completed' as const,
    audience: 'CS Faculty (18)',
    readRate: 100,
    totalRecipients: 18,
    readCount: 18,
  },
  {
    id: '4',
    sender: 'You',
    senderRole: 'HOD - Computer Science',
    category: 'Campus',
    title: 'Guest Lecture: Machine Learning in Healthcare',
    preview: 'Join us for an exciting guest lecture by Dr. Emily Chen from MIT...',
    fullContent: 'We are excited to host Dr. Emily Chen from MIT who will speak about the latest developments in Machine Learning applications in Healthcare. The lecture will be held on April 20, 2026.',
    hasAttachment: false,
    timestamp: '5 days ago',
    isRead: true,
    urgency: 'info' as const,
    audience: 'All Departments (1,245)',
    readRate: 62,
    totalRecipients: 1245,
    readCount: 772,
  },
];

interface FacultyDashboardProps {
  searchQuery: string;
  onNotificationClick: (notification: any) => void;
}

export default function FacultyDashboard({ searchQuery, onNotificationClick }: FacultyDashboardProps) {
  const filteredNotifications = mockSentNotifications.filter(
    (notif) =>
      notif.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notif.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notif.audience.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Analytics Overview */}
      <section className="mb-8">
        <div className="mb-4">
          <h2 className="text-2xl font-semibold text-foreground">Analytics Overview</h2>
          <p className="text-sm text-muted-foreground mt-1">Track your communication effectiveness</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {mockMetrics.map((metric, index) => (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <MetricCard {...metric} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Sent Notifications */}
      <section>
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Sent Notifications</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {mockSentNotifications.length} notifications sent this month
            </p>
          </div>
          <div className="flex gap-2">
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              All
            </button>
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              This Week
            </button>
            <button className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-secondary transition-colors">
              Urgent
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification, index) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <NotificationCard
                  {...notification}
                  onClick={() => onNotificationClick(notification)}
                  role="faculty"
                />
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <p>No notifications found matching "{searchQuery}"</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
