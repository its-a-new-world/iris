import { useState } from 'react';
import { Bell, Search, Plus, Users, GraduationCap } from 'lucide-react';
import Sidebar from './components/Sidebar';
import StudentDashboard from './components/StudentDashboard';
import FacultyDashboard from './components/FacultyDashboard';
import NotificationModal from './components/NotificationModal';

type UserRole = 'student' | 'faculty';

export default function App() {
  const [role, setRole] = useState<UserRole>('student');
  const [selectedNotification, setSelectedNotification] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="size-full flex bg-background overflow-hidden">
      {/* Sidebar */}
      <Sidebar role={role} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-border bg-card px-6 flex items-center justify-between sticky top-0 z-10 backdrop-blur-sm bg-card/95">
          <div className="flex-1 max-w-xl">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search notices, deadlines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-3 ml-6">
            {/* Role Toggle */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-lg border border-border">
              <button
                onClick={() => setRole('student')}
                className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-2 ${
                  role === 'student'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <GraduationCap className="size-4" />
                <span className="text-sm">Student</span>
              </button>
              <button
                onClick={() => setRole('faculty')}
                className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-2 ${
                  role === 'faculty'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Users className="size-4" />
                <span className="text-sm">Faculty</span>
              </button>
            </div>

            {/* Notifications */}
            <button className="relative p-2 hover:bg-secondary rounded-lg transition-colors">
              <Bell className="size-5 text-foreground" />
              <span className="absolute top-1 right-1 size-2 bg-urgent rounded-full" />
            </button>

            {/* New Notification Button (Faculty only) */}
            {role === 'faculty' && (
              <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-hover transition-colors flex items-center gap-2 shadow-sm">
                <Plus className="size-4" />
                <span className="text-sm">New Notice</span>
              </button>
            )}
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 overflow-y-auto">
          {role === 'student' ? (
            <StudentDashboard searchQuery={searchQuery} onNotificationClick={setSelectedNotification} />
          ) : (
            <FacultyDashboard searchQuery={searchQuery} onNotificationClick={setSelectedNotification} />
          )}
        </main>
      </div>

      {/* Notification Modal */}
      {selectedNotification && (
        <NotificationModal
          notification={selectedNotification}
          onClose={() => setSelectedNotification(null)}
          role={role}
        />
      )}
    </div>
  );
}
